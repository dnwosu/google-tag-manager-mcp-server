export const TAG_MANAGER_REMOVE_MCP_SERVER_DATA = "gtm_remove_session";
